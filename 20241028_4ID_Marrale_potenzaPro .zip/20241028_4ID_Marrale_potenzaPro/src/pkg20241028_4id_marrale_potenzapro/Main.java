/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg20241028_4id_marrale_potenzapro;

/**
 *
 * Marrale Lorenzo 4INFD
 * Scrivere un programma che simula il funzionamento della funzione potenza che si studia in matematica
 * 
 */


public class Main {

   
    public static void main(String[] args) {
        
        
        //crea un'istanza della classe request per gestire l'input
        request richiesta_dati = new request();
        //chiede all'utente di inserire i valori di base ed esponente
        richiesta_dati.scanning();
        
        //crea un'istanza della classe operation e passa l'istanza di request
        operation operazione = new operation(richiesta_dati);
        //esegue il calcolo della potenza e stampa il risultato
        operazione.forsure();
        
        
    }
    
}
