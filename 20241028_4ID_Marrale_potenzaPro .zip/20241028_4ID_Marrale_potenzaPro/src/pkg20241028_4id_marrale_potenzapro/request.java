/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg20241028_4id_marrale_potenzapro;
import java.util.Scanner; 

/**
 *
 * Marrale Lorenzo 4INFD
 * classe che svolge la funzione di richiesta all'utente che poi immagazinerà
 * 
 */

public class request {
    
    //variabili private per memorizzare la base e l'esponente inseriti dall'utente
    private int base;
    private int esponente;
    
    //metodo get_base per ottenere il valore di base
    public int get_base(){
        
        return base;
        
    }
    
    //metodo get_esponente per ottenere il valore di esponente
    public int get_esponente(){
        
        return esponente;
        
    }
    
    //metodo per ottenere input dall'utente e impostare base ed esponente
    public void scanning(){
    
        //crea un oggetto Scanner per leggere l'input
        Scanner scanner = new Scanner(System.in);
        //chiede e legge il valore della base
        System.out.print("Inserisci valore base: ");
        base = scanner.nextInt();
        //chiede e legge il valore dell'esponente
        System.out.print("Inserisci valore esponente: ");
        esponente = scanner.nextInt();
    
}
}
