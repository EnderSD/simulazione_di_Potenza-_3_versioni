/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg20241028_4id_marrale_potenzapro;

/**
 *
 * Marrale Lorenzo 4INFD
 * creazione classe utilizzata per svolgere l'operazione che simula la potenza
 * 
 */

public class operation {

    
    //tiene traccia dell'oggetto request fornito
    private request ex;
    //variabile per il risultato della potenza inizializzata a 1 
    private int prodotto = 1;
    
    //il costruttore della classe operation riceve un oggetto di tipo request come parametro e lo memorizza nel campo ex della classe
    public operation(request ex)
    
    {
        //viene utilizzato this per "chiarire" che ci si sta riferendo al campo dell'istanza ex della classe e non al parametro
        this.ex = ex;
        
    }
    
    //metodo per calcolare la potenza e stampare il risultato
    public void forsure(){
    
        //ciclo for per moltiplicare prodotto per il valore di base ripetuto tante volte quanto il valore dell'esponente
        for(int i = 0; i < ex.get_esponente(); i++)
            
        {
            
            //operazione per calcolare il prodotto
            prodotto = prodotto* ex.get_base();
            
        }
        
        //stampa risultato della potenza
        System.out.println("il risultato della potenza e' " + prodotto);
}    
}
